const chatContainer = document.getElementById('chat-container');
const userInput = document.getElementById('user-input');

function addMessage(text, user = false) {
  const msg = document.createElement('div');
  msg.className = 'message' + (user ? ' user' : '');
  msg.textContent = text;
  chatContainer.appendChild(msg);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function sendMessage() {
  const text = userInput.value.trim();
  if (!text) return;
  addMessage(text, true);
  userInput.value = '';

  // Пример простого ответа
  setTimeout(() => {
    addMessage('Вы написали: ' + text);
  }, 500);
}

// Отправка по Enter
userInput.addEventListener('keydown', function(e) {
  if (e.key === 'Enter') sendMessage();
});
